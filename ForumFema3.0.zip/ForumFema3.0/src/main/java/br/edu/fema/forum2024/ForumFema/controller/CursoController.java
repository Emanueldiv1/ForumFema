package br.edu.fema.forum2024.ForumFema.controller;

import java.net.URI;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import br.edu.fema.forum2024.ForumFema.model.DTO.*;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.UriComponentsBuilder;

import br.edu.fema.forum2024.ForumFema.model.Curso;
import br.edu.fema.forum2024.ForumFema.repository.CursosRepository;
import javax.validation.Valid;


@RestController
@RequestMapping("/cursos")
public class CursoController {
	@Autowired
	private CursosRepository cursosRepository;


	@GetMapping
	public List<Curso> listarCursos(){
		return cursosRepository.findAll();

	}

	@GetMapping("/{id}")
	public Optional<Curso> procurarCurso(@PathVariable("id") Long id){
		return cursosRepository.findById(id);

	}
	
	/*metodo POST*/
	@PostMapping
	public ResponseEntity<CursoDto> cadastrar(@RequestBody @Valid  CursosForm form, UriComponentsBuilder uriBuilder){
		Curso curso = form.converter(cursosRepository);
		cursosRepository.save(curso);
		
		URI uri = uriBuilder.path("/cursos/{id}").buildAndExpand(curso.getId()).toUri();
		return ResponseEntity.created(uri).body(new CursoDto(curso));
	}

	@PutMapping("/{id}")
	@Transactional
	public ResponseEntity<CursoDto> atualizar(@PathVariable Long id, @RequestBody @Valid AtualizacaoCursoForm form) {
		Optional<Curso>  optional = cursosRepository.findById(id);
		if (optional.isPresent()){
			Curso curso = form.atualizarCursos(id, cursosRepository);
			return ResponseEntity.ok(new CursoDto(curso));
		}
		return ResponseEntity.notFound().build();
	}

	@DeleteMapping("/{id}")
	@Transactional
	public ResponseEntity<?> remover(@PathVariable Long id){
		Optional<Curso> optional = cursosRepository.findById(id);
		if (optional.isPresent()){
			cursosRepository.deleteById(id);
			return ResponseEntity.ok().build();
		}
		return  ResponseEntity.notFound().build();
	}



}
