package br.edu.fema.forum2024.ForumFema.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import br.edu.fema.forum2024.ForumFema.model.StatusTopico;
import br.edu.fema.forum2024.ForumFema.model.Topico;


public interface TopicosRepository extends JpaRepository<Topico,Long> {
	
	
	List<Topico> findByCursoNome(String nomeCurso);

    List<Topico> findByStatus(StatusTopico status);
	

}
