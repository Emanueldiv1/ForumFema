package br.edu.fema.forum2024.ForumFema.model;

public enum StatusTopico {

    NAO_RESPONDIDO,
    NAO_SOLUCIONADO,
    SOLUCIONADO,
    FECHADO;
}
