package br.edu.fema.forum2024.ForumFema;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ForumFemaApplicationTests {

	@Test
	void contextLoads() {
	}

}
